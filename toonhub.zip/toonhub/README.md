# ToonHub Web Application

## 📝 Project Description

ToonHub is a comprehensive web application designed for managing and exploring animated/entertainment content. This project provides a robust platform for users to interact with and discover various animated/media.

## 🛠 Technology Stack

- **Backend:** PHP 7.4+
- **Database:** MySQL
- **Frontend:** HTML5, CSS3, JavaScript
- **Development Environment:** XAMPP/WAMP/MAMP

## 🚀 Quick Start Guide

### Prerequisites

- Web Server (XAMPP/WAMP/MAMP)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web Browser

### Installation Steps

#### 1. Local Environment Setup

1. Download and install XAMPP/WAMP/MAMP
2. Ensure Apache and MySQL services are running

#### 2. Database Configuration

1. Open phpMyAdmin
2. Create a new database:
   ```sql
   CREATE DATABASE toonhub
   CHARACTER SET utf8mb4 
   COLLATE utf8mb4_general_ci;
   ```
3. Import database schema:
   - Navigate to the `toonhub` database
   - Use the "Import" tab
   - Upload and execute the provided SQL file

#### 3. Project Deployment

1. Clone or copy the project to your web server's document root:
   - XAMPP: `C:\xampp\htdocs\toonhub`
   - WAMP: `C:\wamp\www\toonhub`

#### 4. Database Connection

Update `config.php` with your database credentials:

```php
<?php
$host = 'localhost';
$username = 'root';     // Default XAMPP/WAMP username
$password = '';         // Default XAMPP/WAMP password
$database = 'toonhub';
?>
```

### 🔐 Forgot Password Module

#### Overview

The `forgot.php` module provides a secure password reset mechanism:

- Generates time-limited reset tokens
- Sends password reset links via email
- Enhances user account security

#### Email Configuration

1. Open `forgot.php`
2. Configure SMTP settings:
   ```php
   $mail->Host = 'smtp.example.com';
   $mail->Username = 'your_email@example.com';
   $mail->Password = 'your_secure_app_password';
   ```

#### Recommended Email Services

- Gmail (requires app password)
- SendGrid
- Mailgun
- Amazon SES

### 🌐 Accessing the Application

- Open your web browser
- Navigate to: `http://localhost/toonhub/index.php`
- Landing page: `index.php`

## 🛡️ Security Best Practices

- Use HTTPS in production environments
- Implement rate limiting
- Generate strong, unique tokens
- Secure email credentials
- Regularly update dependencies
- Use prepared statements to prevent SQL injection

## 🐛 Troubleshooting

### Common Issues

- Verify Apache and MySQL are running
- Check database connection settings
- Ensure proper file permissions
- Validate SMTP email configuration

## 📋 Additional Notes

- Default login credentials are included in the SQL import
- First-time setup may require additional configuration

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a pull request

## 📄 License

[Specify your project's license here]

## 📧 Contact

[Your contact information or support email]

---

**Note:** Always keep your credentials and sensitive information secure and never commit them to version control.
